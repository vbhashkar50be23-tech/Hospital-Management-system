<?php
require_once 'config.php';

try {
    echo "<h3>Creating Receptionist User:</h3>";
    
    // First, check if receptionist already exists
    $existingReceptionist = $mongoOps->db->receptionists->findOne(['username' => 'admin']);
    
    if ($existingReceptionist) {
        echo "<p style='color: orange;'>Receptionist user already exists!</p>";
        echo "<pre>";
        echo "Username: " . $existingReceptionist['username'] . "\n";
        echo "Created At: " . date('Y-m-d H:i:s', $existingReceptionist['created_at']->toDateTime()->getTimestamp()) . "\n";
        echo "</pre>";
    } else {
        // Create new receptionist user
        $receptionistData = [
            'username' => 'admin',
            'password' => password_hash('admin123', PASSWORD_DEFAULT),
            'created_at' => new MongoDB\BSON\UTCDateTime()
        ];
        
        $result = $mongoOps->db->receptionists->insertOne($receptionistData);
        
        if ($result->getInsertedCount() > 0) {
            echo "<p style='color: green;'>Receptionist user created successfully!</p>";
            echo "<p>Username: admin</p>";
            echo "<p>Password: admin123</p>";
            
            // Verify the stored user
            $storedUser = $mongoOps->db->receptionists->findOne(['username' => 'admin']);
            if ($storedUser) {
                echo "<p style='color: green;'>User verification successful!</p>";
                echo "<pre>";
                echo "Username: " . $storedUser['username'] . "\n";
                echo "Created At: " . date('Y-m-d H:i:s', $storedUser['created_at']->toDateTime()->getTimestamp()) . "\n";
                echo "</pre>";
                
                // Test password verification
                if (password_verify('admin123', $storedUser['password'])) {
                    echo "<p style='color: green;'>Password verification successful!</p>";
                } else {
                    echo "<p style='color: red;'>Password verification failed!</p>";
                }
            }
        } else {
            echo "<p style='color: red;'>Failed to create receptionist user!</p>";
        }
    }
    
    // Show all receptionists in the collection
    echo "<h3>All Receptionists in Database:</h3>";
    $receptionists = $mongoOps->db->receptionists->find()->toArray();
    if (count($receptionists) > 0) {
        foreach ($receptionists as $receptionist) {
            echo "<pre>";
            echo "Username: " . $receptionist['username'] . "\n";
            echo "Created At: " . date('Y-m-d H:i:s', $receptionist['created_at']->toDateTime()->getTimestamp()) . "\n";
            echo "</pre>";
        }
    } else {
        echo "<p style='color: red;'>No receptionists found in database!</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
    echo "<pre>";
    echo "Error Code: " . $e->getCode() . "\n";
    echo "Error Message: " . $e->getMessage() . "\n";
    echo "Stack Trace:\n" . $e->getTraceAsString() . "\n";
    echo "</pre>";
}
?> 