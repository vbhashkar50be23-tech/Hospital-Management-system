<?php
session_start();
require_once 'config.php';
require_once 'mongodb_operations.php';

if(isset($_POST['adsub'])) {
	$username = $_POST['username1'];
	$password = $_POST['password2'];
	
	try {
		// Check in receptionists collection
		$admin = $mongoOps->db->receptionists->findOne([
			'username' => $username,
			'role' => 'Administrator'
		]);
		
		if($admin && password_verify($password, $admin['password'])) {
			$_SESSION['username'] = $username;
			$_SESSION['role'] = $admin['role'];
			$_SESSION['rid'] = (string)$admin['_id'];
			header("Location:admin-panel.php");
			exit();
		} else {
			echo("<script>alert('Invalid Username or Password. Try Again!');
				  window.location.href = 'index.php';</script>");
		}
	} catch (Exception $e) {
		echo("<script>alert('Error: " . $e->getMessage() . "');
			  window.location.href = 'index.php';</script>");
	}
}

if(isset($_POST['update_data']))
{
	$contact=$_POST['contact'];
	$status=$_POST['status'];
	
	try {
		$result = $mongoOps->updateAppointmentStatus($contact, $status);
		if($result->getModifiedCount() > 0) {
			header("Location:updated.php");
		} else {
			echo("<script>alert('No appointment found with that contact number!');
				  window.location.href = 'admin-panel.php';</script>");
		}
	} catch (Exception $e) {
		echo("<script>alert('Error: " . $e->getMessage() . "');
			  window.location.href = 'admin-panel.php';</script>");
	}
}

function display_docs()
{
	global $mongoOps;
	try {
		$doctors = $mongoOps->db->doctors->find([], [
			'projection' => ['username' => 1, '_id' => 0]
		])->toArray();
		
		foreach($doctors as $doctor) {
			echo '<option value="'.htmlspecialchars($doctor['username']).'">'.htmlspecialchars($doctor['username']).'</option>';
		}
	} catch (Exception $e) {
		echo "Error fetching doctors: " . $e->getMessage();
	}
}

if(isset($_POST['doc_sub']))
{
	$name=$_POST['name'];
	
	try {
		$result = $mongoOps->createDoctor([
			'username' => $name,
			'password' => '', // You might want to set a default password
			'email' => '',
			'spec' => '',
			'docFees' => 0
		]);
		
		if($result) {
			header("Location:adddoc.php");
		}
	} catch (Exception $e) {
		echo("<script>alert('Error: " . $e->getMessage() . "');
			  window.location.href = 'adddoc.php';</script>");
	}
}
