<?php
session_start();
require_once 'config.php';
require_once 'mongodb_operations.php';

// Debug: Print session contents
error_log("Doctor panel accessed. Session contents: " . print_r($_SESSION, true));

// Check if doctor is logged in
if(!isset($_SESSION['username']) || !isset($_SESSION['did'])) {
    error_log("Session check failed. Redirecting to index.php");
    header("Location: index.php");
    exit();
}

// Debug: Print successful session check
error_log("Session check passed. Doctor logged in: " . $_SESSION['username']);

$doctorName = $_SESSION['username'];
$did = $_SESSION['did'];

// Get doctor's name for display
$displayName = ucfirst($doctorName);

// Get doctor's appointments
try {
    $appointments = $mongoOps->db->appointments->find(
        ['doctor' => $doctorName],
        ['sort' => ['appdate' => -1, 'apptime' => -1]]
    )->toArray();
} catch (Exception $e) {
    $appointments = [];
}

// Get doctor's prescriptions
try {
    $prescriptions = $mongoOps->db->prescriptions->find(
        ['doctor' => $doctorName],
        ['sort' => ['created_at' => -1]]
    )->toArray();
} catch (Exception $e) {
    $prescriptions = [];
}

if(isset($_GET['ID'])) {
    try {
        $result = $mongoOps->db->appointments->updateOne(
            ['_id' => new MongoDB\BSON\ObjectId($_GET['ID'])],
            ['$set' => ['doctorStatus' => 0]]
        );
        if($result->getModifiedCount() > 0) {
            echo "<script>alert('Appointment cancelled successfully!');</script>";
        }
    } catch (Exception $e) {
        echo "<script>alert('Error: " . $e->getMessage() . "');</script>";
    }
}

if(isset($_POST['psub'])) {
    $doctor = $_POST['doctor'];
    $pid = $_POST['pid'];
    $ID = $_POST['ID'];
    $disease = $_POST['disease'];
    $allergy = $_POST['allergy'];
    $prescription = $_POST['prescription'];
    $appdate = $_POST['appdate'];
    $apptime = $_POST['apptime'];
    
    try {
        $prescriptionData = [
            'doctor' => $doctor,
            'pid' => (int)$pid,
            'ID' => $ID,
            'appdate' => new MongoDB\BSON\UTCDateTime(strtotime($appdate) * 1000),
            'apptime' => $apptime,
            'disease' => $disease,
            'allergy' => $allergy,
            'prescription' => $prescription
        ];
        
        $result = $mongoOps->db->prescriptions->insertOne($prescriptionData);
        if($result->getInsertedCount() > 0) {
            echo "<script>alert('Prescription added successfully!');</script>";
        }
    } catch (Exception $e) {
        echo "<script>alert('Error: " . $e->getMessage() . "');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="style.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <title>Doctor Dashboard</title>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
      <a class="navbar-brand" href="#"><i class="fa fa-user-md" aria-hidden="true"></i> Global Hospital</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
         <ul class="navbar-nav mr-auto">
           <li class="nav-item">
            <a class="nav-link" href="logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i>Logout</a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="#"></a>
          </li>
        </ul>
      </div>
    </nav>
  </head>
  <style type="text/css">
    button:hover{cursor:pointer;}
    #inputbtn:hover{cursor:pointer;}
  </style>
  <body style="padding-top:50px;">
   <div class="container-fluid" style="margin-top:50px;">
    <div class="row mb-4">
        <div class="col-12">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h2 class="card-title">Welcome Dr. <?php echo htmlspecialchars($displayName); ?>!</h2>
                    <p class="card-text">Manage your appointments and patient prescriptions here.</p>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
  <div class="col-md-4" style="max-width:25%;margin-top: 3%;">
    <div class="list-group" id="list-tab" role="tablist">
      <a class="list-group-item list-group-item-action active" id="list-home-list" data-toggle="list" href="#list-home" role="tab">My Appointments</a>
      <a class="list-group-item list-group-item-action" id="list-prescriptions-list" data-toggle="list" href="#list-prescriptions" role="tab">Prescriptions</a>
      <a class="list-group-item list-group-item-action" id="list-write-prescription-list" data-toggle="list" href="#list-write-prescription" role="tab">Write Prescription</a>
      <a class="list-group-item list-group-item-action" id="list-settings-list" data-toggle="list" href="#list-settings" role="tab">My Profile</a>
    </div><br>
  </div>
  <div class="col-md-8" style="margin-top: 3%;">
    <div class="tab-content" id="nav-tabContent" style="width: 950px;">
      <div class="tab-pane fade show active" id="list-home" role="tabpanel">
        <div class="card">
          <div class="card-body">
            <h4>My Appointments</h4>
            <?php if(empty($appointments)): ?>
                <p>No appointments found.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Patient</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Status</th>
                                <th>Fee</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($appointments as $appointment): 
                                // Get patient details
                                $patient = $mongoOps->db->patients->findOne(['_id' => new MongoDB\BSON\ObjectId($appointment['pid'])]);
                                $patientName = $patient ? $patient['fname'] . ' ' . $patient['lname'] : 'Unknown';
                            ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($patientName); ?></td>
                                    <td><?php echo htmlspecialchars($appointment['appdate']); ?></td>
                                    <td><?php echo htmlspecialchars($appointment['apptime']); ?></td>
                                    <td>
                                        <span class="badge badge-<?php 
                                            echo $appointment['status'] === 'Pending' ? 'warning' : 
                                                ($appointment['status'] === 'Confirmed' ? 'success' : 'danger'); 
                                        ?>">
                                            <?php echo htmlspecialchars($appointment['status']); ?>
                                        </span>
                                    </td>
                                    <td>₹<?php echo htmlspecialchars($appointment['docFees']); ?></td>
                                    <td>
                                        <?php if($appointment['status'] === 'Pending'): ?>
                                            <form method="post" action="update-appointment.php" style="display: inline;">
                                                <input type="hidden" name="appointment_id" value="<?php echo $appointment['_id']; ?>">
                                                <button type="submit" name="confirm" class="btn btn-success btn-sm">Confirm</button>
                                                <button type="submit" name="cancel" class="btn btn-danger btn-sm">Cancel</button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <div class="tab-pane fade" id="list-prescriptions" role="tabpanel">
        <div class="card">
          <div class="card-body">
            <h4>Prescriptions</h4>
            <?php if(empty($prescriptions)): ?>
                <p>No prescriptions found.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Patient</th>
                                <th>Date</th>
                                <th>Diagnosis</th>
                                <th>Medications</th>
                                <th>Follow-up</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($prescriptions as $prescription): 
                                $patient = $mongoOps->db->patients->findOne(['_id' => new MongoDB\BSON\ObjectId($prescription['pid'])]);
                                $patientName = $patient ? $patient['fname'] . ' ' . $patient['lname'] : 'Unknown';
                                $date = $prescription['date']->toDateTime()->format('Y-m-d');
                            ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($patientName); ?></td>
                                    <td><?php echo htmlspecialchars($date); ?></td>
                                    <td><?php echo htmlspecialchars($prescription['diagnosis']); ?></td>
                                    <td>
                                        <?php foreach($prescription['medications'] as $med): ?>
                                            <div><?php echo htmlspecialchars($med['name'] . ' - ' . $med['dosage']); ?></div>
                                        <?php endforeach; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($prescription['follow_up_date'] ?? 'Not specified'); ?></td>
                                    <td>
                                        <a href="print_prescription.php?id=<?php echo $prescription['_id']; ?>" class="btn btn-info btn-sm" target="_blank">Print</a>
                                        <a href="delete_prescription.php?id=<?php echo $prescription['_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this prescription?')">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <div class="tab-pane fade" id="list-write-prescription" role="tabpanel">
        <div class="card">
          <div class="card-body">
            <h4>Write New Prescription</h4>
            <p>Click the button below to write a new prescription for a patient.</p>
            <a href="write_prescription.php" class="btn btn-primary">Write Prescription</a>
          </div>
        </div>
      </div>

      <div class="tab-pane fade" id="list-settings" role="tabpanel">
        <div class="card">
          <div class="card-body">
            <h4>My Profile</h4>
            <?php
            $doctorInfo = $mongoOps->db->doctors->findOne(['username' => $doctorName]);
            if($doctorInfo):
            ?>
            <div class="row">
                <div class="col-md-4"><label>Name:</label></div>
                <div class="col-md-8">Dr. <?php echo htmlspecialchars($displayName); ?></div>
                <div class="col-md-4"><label>Specialty:</label></div>
                <div class="col-md-8"><?php echo htmlspecialchars($doctorInfo['spec']); ?></div>
                <div class="col-md-4"><label>Email:</label></div>
                <div class="col-md-8"><?php echo htmlspecialchars($doctorInfo['email']); ?></div>
                <div class="col-md-4"><label>Consultation Fee:</label></div>
                <div class="col-md-8">₹<?php echo htmlspecialchars($doctorInfo['docFees']); ?></div>
            </div>
            <div class="mt-3">
                <a href="update_profile.php" class="btn btn-primary">Edit Profile</a>
            </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
   </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
  </body>
</html>