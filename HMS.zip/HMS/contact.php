<?php 
require_once 'config.php';
require_once 'mongodb_operations.php';

if(isset($_POST['btnSubmit']))
{
	$name = $_POST['txtName'];
	$email = $_POST['txtEmail'];
	$contact = $_POST['txtPhone'];
	$message = $_POST['txtMsg'];

	try {
		$result = $mongoOps->db->contacts->insertOne([
			'name' => $name,
			'email' => $email,
			'contact' => $contact,
			'message' => $message,
			'created_at' => new MongoDB\BSON\UTCDateTime()
		]);
		
		if($result->getInsertedCount() > 0) {
			echo '<script type="text/javascript">'; 
			echo 'alert("Message sent successfully!");'; 
			echo 'window.location.href = "contact.html";';
			echo '</script>';
		}
	} catch (Exception $e) {
		echo '<script type="text/javascript">'; 
		echo 'alert("Error: ' . $e->getMessage() . '");'; 
		echo 'window.location.href = "contact.html";';
		echo '</script>';
	}
}