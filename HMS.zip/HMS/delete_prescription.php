<?php
session_start();
require_once 'config.php';
require_once 'mongodb_operations.php';

// Check if doctor is logged in
if(!isset($_SESSION['username']) || !isset($_SESSION['did'])) {
    header("Location: index.php");
    exit();
}

if(isset($_GET['id'])) {
    try {
        // Verify that the prescription belongs to this doctor
        $prescription = $mongoOps->db->prescriptions->findOne([
            '_id' => new MongoDB\BSON\ObjectId($_GET['id']),
            'doctor' => $_SESSION['username']
        ]);

        if($prescription) {
            // Delete the prescription
            $result = $mongoOps->db->prescriptions->deleteOne([
                '_id' => new MongoDB\BSON\ObjectId($_GET['id'])
            ]);

            if($result->getDeletedCount() > 0) {
                echo "<script>alert('Prescription deleted successfully!');</script>";
            } else {
                echo "<script>alert('Failed to delete prescription.');</script>";
            }
        } else {
            echo "<script>alert('Prescription not found or unauthorized.');</script>";
        }
    } catch (Exception $e) {
        echo "<script>alert('Error: " . $e->getMessage() . "');</script>";
    }
}

// Redirect back to doctor panel
echo "<script>window.location.href = 'doctor-panel.php';</script>";
?> 