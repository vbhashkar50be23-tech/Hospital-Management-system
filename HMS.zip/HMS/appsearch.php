<!DOCTYPE html>
<?php #include("func.php");?>
<html>
<head>
	<title>Patient Details</title>
  <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">

</head>
<body>
<?php
require_once 'config.php';
require_once 'mongodb_operations.php';

if(isset($_POST['app_search_submit'])) {
    $contact = $_POST['app_contact'];
    try {
        $appointments = $mongoOps->db->appointments->find(['contact' => $contact])->toArray();
        if(count($appointments) > 0) {
            echo '<div class="container-fluid" style="margin-top:50px;">
                    <div class="card">
                        <div class="card-body" style="background-color:#342ac1;color:#ffffff;">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">Appointment ID</th>
                                        <th scope="col">Patient Name</th>
                                        <th scope="col">Doctor</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Time</th>
                                        <th scope="col">Status</th>
                                    </tr>
                                </thead>
                                <tbody>';
            
            foreach($appointments as $appointment) {
                $appdate = $appointment['appdate']->toDateTime()->format('Y-m-d');
                $status = "Active";
                if($appointment['userStatus'] == 0 && $appointment['doctorStatus'] == 1) {
                    $status = "Cancelled by Patient";
                } else if($appointment['userStatus'] == 1 && $appointment['doctorStatus'] == 0) {
                    $status = "Cancelled by Doctor";
                }
                
                echo '<tr>
                        <td>'.htmlspecialchars($appointment['_id']).'</td>
                        <td>'.htmlspecialchars($appointment['fname'].' '.$appointment['lname']).'</td>
                        <td>'.htmlspecialchars($appointment['doctor']).'</td>
                        <td>'.htmlspecialchars($appdate).'</td>
                        <td>'.htmlspecialchars($appointment['apptime']).'</td>
                        <td>'.htmlspecialchars($status).'</td>
                    </tr>';
            }
            
            echo '</tbody></table>
                    <center><a href="admin-panel.php" class="btn btn-light">Back to dashboard</a></center>
                </div></div></div>';
        } else {
            echo '<div class="alert alert-danger">
                    <strong>No appointments found for this contact number!</strong>
                  </div>';
        }
    } catch (Exception $e) {
        echo '<div class="alert alert-danger">
                <strong>Error: '.htmlspecialchars($e->getMessage()).'</strong>
              </div>';
    }
}
?>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script> 
</body>
</html>