<?php
session_start();
require_once 'config.php';
require_once 'mongodb_operations.php';

// Check if user is logged in
if(!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

$username = $_SESSION['username'];
$isDoctor = isset($_SESSION['did']);
$isPatient = isset($_SESSION['pid']);

// Handle form submission
if(isset($_POST['update_profile'])) {
    try {
        if($isDoctor) {
            // Update doctor profile
            $updateData = [
                'email' => $_POST['email'],
                'phone' => $_POST['phone'],
                'address' => $_POST['address']
            ];
            
            // Only update password if a new one is provided
            if(!empty($_POST['new_password'])) {
                if(password_verify($_POST['current_password'], $doctor['password'])) {
                    $updateData['password'] = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
                } else {
                    throw new Exception("Current password is incorrect");
                }
            }

            $result = $mongoOps->db->doctors->updateOne(
                ['username' => $username],
                ['$set' => $updateData]
            );
        } else if($isPatient) {
            // Update patient profile
            $updateData = [
                'email' => $_POST['email'],
                'contact' => $_POST['phone'],
                'address' => $_POST['address']
            ];
            
            // Only update password if a new one is provided
            if(!empty($_POST['new_password'])) {
                if(password_verify($_POST['current_password'], $patient['password'])) {
                    $updateData['password'] = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
                } else {
                    throw new Exception("Current password is incorrect");
                }
            }

            $result = $mongoOps->db->patients->updateOne(
                ['_id' => new MongoDB\BSON\ObjectId($_SESSION['pid'])],
                ['$set' => $updateData]
            );
        }

        if($result->getModifiedCount() > 0) {
            echo "<script>alert('Profile updated successfully!');</script>";
        } else {
            echo "<script>alert('No changes were made.');</script>";
        }
    } catch (Exception $e) {
        echo "<script>alert('Error: " . $e->getMessage() . "');</script>";
    }
}

// Get current user data
try {
    if($isDoctor) {
        $userData = $mongoOps->db->doctors->findOne(['username' => $username]);
        $userType = 'Doctor';
    } else if($isPatient) {
        $userData = $mongoOps->db->patients->findOne(['_id' => new MongoDB\BSON\ObjectId($_SESSION['pid'])]);
        $userType = 'Patient';
    }
} catch (Exception $e) {
    echo "<script>alert('Error: " . $e->getMessage() . "');</script>";
    $userData = null;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css">
    <title>Update Profile</title>
</head>
<body>
    <div class="container mt-5">
        <h2>Update <?php echo $userType; ?> Profile</h2>
        <?php if($userData): ?>
        <form method="post" action="">
            <div class="form-group">
                <label>Username:</label>
                <input type="text" class="form-control" value="<?php echo htmlspecialchars($username); ?>" readonly>
            </div>

            <div class="form-group">
                <label>Name:</label>
                <input type="text" class="form-control" value="<?php
                    if (!empty($userData['fname']) || !empty($userData['lname'])) {
                        echo htmlspecialchars(($userData['fname'] ?? '') . ' ' . ($userData['lname'] ?? ''));
                    } elseif (!empty($userData['name'])) {
                        echo htmlspecialchars($userData['name']);
                    } else {
                        echo htmlspecialchars($username);
                    }
                ?>" readonly>
            </div>

            <div class="form-group">
                <label>Email:</label>
                <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($userData['email'] ?? ''); ?>" required>
            </div>

            <div class="form-group">
                <label>Phone:</label>
                <input type="tel" name="phone" class="form-control" value="<?php echo htmlspecialchars($userData['phone'] ?? $userData['contact'] ?? ''); ?>" required>
            </div>

            <div class="form-group">
                <label>Address:</label>
                <textarea name="address" class="form-control" rows="3"><?php echo htmlspecialchars($userData['address'] ?? ''); ?></textarea>
            </div>

            <h4>Change Password (Optional)</h4>
            <div class="form-group">
                <label>Current Password:</label>
                <input type="password" name="current_password" class="form-control">
            </div>

            <div class="form-group">
                <label>New Password:</label>
                <input type="password" name="new_password" class="form-control">
            </div>

            <button type="submit" name="update_profile" class="btn btn-primary">Update Profile</button>
            <?php if($isDoctor): ?>
                <a href="doctor-panel.php" class="btn btn-secondary">Back to Dashboard</a>
            <?php else: ?>
                <a href="patient-panel.php" class="btn btn-secondary">Back to Dashboard</a>
            <?php endif; ?>
        </form>
        <?php else: ?>
            <div class="alert alert-danger">Error loading user data.</div>
        <?php endif; ?>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js"></script>
</body>
</html> 