<!DOCTYPE html>
<html>
<head>
	<title>User Messages</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
</head>
<body>
<?php
require_once 'config.php';
require_once 'mongodb_operations.php';

if(isset($_POST['mes_search_submit']))
{
	$contact=$_POST['mes_contact'];
	
	try {
		$message = $mongoOps->db->contacts->findOne(['contact' => $contact]);
		
		if(!$message) {
			echo "<script> alert('No entries found! Please enter valid details'); 
				  window.location.href = 'admin-panel1.php#list-doc';</script>";
		} else {
			echo "<div class='container-fluid' style='margin-top:50px;'>
			<div class='card'>
			<div class='card-body' style='background-color:#342ac1;color:#ffffff;'>
			<table class='table table-hover'>
				<thead>
					<tr>
						<th scope='col'>User Name</th>
						<th scope='col'>Email</th>
						<th scope='col'>Contact</th>
						<th scope='col'>Message</th>
					</tr>
				</thead>
				<tbody>";
			
			echo "<tr>
				<td>".htmlspecialchars($message['name'])."</td>
				<td>".htmlspecialchars($message['email'])."</td>
				<td>".htmlspecialchars($message['contact'])."</td>
				<td>".htmlspecialchars($message['message'])."</td>
			</tr>";
			
			echo "</tbody></table><center><a href='admin-panel1.php' class='btn btn-light'>Back to your Dashboard</a></div></center></div></div></div>";
		}
	} catch (Exception $e) {
		echo "<div class='alert alert-danger'>Error: " . htmlspecialchars($e->getMessage()) . "</div>";
	}
}
?>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script> 
</body>
</html>