<?php
// MongoDB Configuration
define('MONGODB_URI', 'mongodb://localhost:27017');
define('MONGODB_DB', 'hmsdb');

// MongoDB Connection
try {
    $mongoClient = new MongoDB\Client(MONGODB_URI);
    $mongoOps = new MongoDB\Operations($mongoClient->selectDatabase(MONGODB_DB));
} catch (Exception $e) {
    die("Failed to connect to MongoDB: " . $e->getMessage());
}

// Session Configuration
session_start();

// Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>