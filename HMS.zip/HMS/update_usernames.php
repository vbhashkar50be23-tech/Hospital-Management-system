<?php
require_once 'config.php';
require_once 'mongodb_operations.php';

try {
    // First, let's check what doctors we have
    $doctors = $mongoOps->db->doctors->find()->toArray();
    echo "<h2>Current Doctors in Database:</h2>";
    echo "<pre>";
    print_r($doctors);
    echo "</pre>";

    // Update usernames
    $updates = [
        ['old' => 'dr.arun', 'new' => 'arun'],
        ['old' => 'dr.kunal', 'new' => 'kunal'],
        ['old' => 'dr.rohit', 'new' => 'rohit']
    ];

    foreach ($updates as $update) {
        // Update in doctors collection
        $result = $mongoOps->db->doctors->updateOne(
            ['username' => $update['old']],
            ['$set' => ['username' => $update['new']]]
        );
        echo "Updated {$update['old']} to {$update['new']} in doctors collection<br>";

        // Update in appointments collection
        $result = $mongoOps->db->appointments->updateMany(
            ['doctor' => $update['old']],
            ['$set' => ['doctor' => $update['new']]]
        );
        echo "Updated appointments for {$update['new']}<br>";

        // Update in prescriptions collection
        $result = $mongoOps->db->prescriptions->updateMany(
            ['doctor' => $update['old']],
            ['$set' => ['doctor' => $update['new']]]
        );
        echo "Updated prescriptions for {$update['new']}<br>";
    }

    // Verify the changes
    $doctors = $mongoOps->db->doctors->find()->toArray();
    echo "<h2>Updated Doctors in Database:</h2>";
    echo "<pre>";
    print_r($doctors);
    echo "</pre>";

    echo "<h2>New Login Credentials:</h2>";
    echo "<ul>";
    echo "<li>Arun (password: doctor123)</li>";
    echo "<li>Kunal (password: doctor123)</li>";
    echo "<li>Rohit (password: doctor123)</li>";
    echo "</ul>";

} catch (Exception $e) {
    echo "<h2>Error:</h2>";
    echo $e->getMessage();
}
?> 