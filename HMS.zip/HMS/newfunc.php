<?php
require_once 'config.php';
require_once 'mongodb_operations.php';

// session_start();
$con=mysqli_connect("localhost","root","","myhmsdb");
// if(isset($_POST['submit'])){
//  $username=$_POST['username'];
//  $password=$_POST['password'];
//  $query="select * from logintb where username='$username' and password='$password';";
//  $result=mysqli_query($con,$query);
//  if(mysqli_num_rows($result)==1)
//  {
//   $_SESSION['username']=$username;
//   $_SESSION['pid']=
//   header("Location:admin-panel.php");
//  }
//  else
//   header("Location:error.php");
// }
if(isset($_POST['update_data']))
{
    $contact = $_POST['contact'];
    $status = $_POST['status'];
    
    try {
        $result = $mongoOps->updateAppointmentStatus($contact, $status);
        if($result->getModifiedCount() > 0) {
            header("Location:updated.php");
        } else {
            echo("<script>alert('No appointment found with that contact number!');
                  window.location.href = 'admin-panel.php';</script>");
        }
    } catch (Exception $e) {
        echo("<script>alert('Error: " . $e->getMessage() . "');
              window.location.href = 'admin-panel.php';</script>");
    }
}

// function display_docs()
// {
//  global $con;
//  $query="select * from doctb";
//  $result=mysqli_query($con,$query);
//  while($row=mysqli_fetch_array($result))
//  {
//   $username=$row['username'];
//   $price=$row['docFees'];
//   echo '<option value="' .$username. '" data-value="'.$price.'">'.$username.'</option>';
//  }
// }

function update_data($contact, $status) {
    global $mongoOps;
    try {
        $result = $mongoOps->db->appointments->updateOne(
            ['contact' => $contact],
            ['$set' => ['userStatus' => (int)$status]]
        );
        return $result->getModifiedCount() > 0;
    } catch (Exception $e) {
        return false;
    }
}

function display_specs() {
    global $mongoOps;
    try {
        $specs = $mongoOps->db->doctors->distinct('spec');
        foreach($specs as $spec) {
            echo '<option value="'.htmlspecialchars($spec).'">'.htmlspecialchars($spec).'</option>';
        }
    } catch (Exception $e) {
        echo '<option value="">Error loading specializations</option>';
    }
}

function display_docs() {
    global $mongoOps;
    try {
        $doctors = $mongoOps->db->doctors->find([], [
            'projection' => ['username' => 1, 'docFees' => 1, 'spec' => 1, '_id' => 0]
        ])->toArray();
        
        foreach($doctors as $doctor) {
            echo '<option value="'.htmlspecialchars($doctor['username']).'" 
                    data-value="'.htmlspecialchars($doctor['docFees']).'"
                    data-spec="'.htmlspecialchars($doctor['spec']).'">'
                    .htmlspecialchars($doctor['username']).'</option>';
        }
    } catch (Exception $e) {
        echo '<option value="">Error loading doctors</option>';
    }
}

// function display_specs() {
//   global $con;
//   $query = "select distinct(spec) from doctb";
//   $result = mysqli_query($con,$query);
//   while($row = mysqli_fetch_array($result))
//   {
//     $spec = $row['spec'];
//     $username = $row['username'];
//     echo '<option value = "' .$spec. '">'.$spec.'</option>';
//   }
// }


if(isset($_POST['doc_sub'])) {
    $username = $_POST['username'];
    try {
        $result = $mongoOps->db->doctors->insertOne([
            'username' => $username,
            'created_at' => new MongoDB\BSON\UTCDateTime()
        ]);
        if($result->getInsertedCount() > 0) {
            header("Location:adddoc.php");
        }
    } catch (Exception $e) {
        echo("<script>alert('Error: " . $e->getMessage() . "');
              window.location.href = 'error.php';</script>");
    }
}

?>