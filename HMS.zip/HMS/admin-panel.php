<?php
require_once 'config.php';
require_once 'mongodb_operations.php';

// --- Handle appointment reschedule POST ---
if (isset($_POST['reschedule_id'], $_POST['new_date'], $_POST['new_time'])) {
    $rescheduleId = $_POST['reschedule_id'];
    $newDate = $_POST['new_date'];
    $newTime = $_POST['new_time'];
    
    try {
        // First get the current appointment details
        $currentAppointment = $mongoOps->db->appointments->findOne([
            '_id' => new MongoDB\BSON\ObjectId($rescheduleId)
        ]);
        
        if (!$currentAppointment) {
            echo "<script>
                alert('Appointment not found!');
                window.location.replace('admin-panel.php');
            </script>";
            exit();
        }
        
        // Check if the new slot is available
        $existingAppointment = $mongoOps->db->appointments->findOne([
            'doctor' => $currentAppointment['doctor'],
            'appdate' => $newDate,
            'apptime' => $newTime,
            '_id' => ['$ne' => new MongoDB\BSON\ObjectId($rescheduleId)]
        ]);
        
        if ($existingAppointment) {
            echo "<script>
                alert('This time slot is already booked! Please choose another time.');
                window.location.replace('admin-panel.php');
            </script>";
            exit();
        }
        
        // Update the appointment
        $result = $mongoOps->db->appointments->updateOne(
            ['_id' => new MongoDB\BSON\ObjectId($rescheduleId)],
            ['$set' => [
                'appdate' => $newDate,
                'apptime' => $newTime
            ]]
        );
        
        if ($result->getModifiedCount() > 0) {
            echo "<script>
                alert('Appointment rescheduled successfully!');
                window.location.replace('admin-panel.php');
            </script>";
            exit();
        } else {
            echo "<script>
                alert('No changes were made to the appointment.');
                window.location.replace('admin-panel.php');
            </script>";
            exit();
        }
    } catch (Exception $e) {
        error_log('Reschedule error: ' . $e->getMessage());
        echo "<script>
            alert('Error rescheduling appointment: " . addslashes($e->getMessage()) . "');
            window.location.replace('admin-panel.php');
        </script>";
        exit();
    }
}

// --- Handle appointment cancel GET ---
if(isset($_GET['ID'])) {
    $cancelId = $_GET['ID'];
    try {
        $result = $mongoOps->db->appointments->updateOne(
            ['_id' => new MongoDB\BSON\ObjectId($cancelId)],
            ['$set' => ['userStatus' => 0]]
        );
        echo "<script>alert('Appointment cancelled successfully!'); window.location.href = 'admin-panel.php#list-app';</script>";
        exit();
    } catch (Exception $e) {
        error_log('Cancel error: ' . $e->getMessage());
        echo "<script>alert('Error cancelling appointment: " . addslashes($e->getMessage()) . "'); window.location.href = 'admin-panel.php#list-app';</script>";
        exit();
    }
}

// --- Handle appointment hard delete GET ---
if(isset($_GET['deleteID'])) {
    $deleteId = $_GET['deleteID'];
    try {
        $result = $mongoOps->db->appointments->deleteOne([
            '_id' => new MongoDB\BSON\ObjectId($deleteId)
        ]);
        if($result->getDeletedCount() > 0) {
            echo "<script>alert('Appointment permanently deleted!'); window.location.href = 'admin-panel.php#list-app';</script>";
            exit();
        } else {
            echo "<script>alert('No appointment deleted.'); window.location.href = 'admin-panel.php#list-app';</script>";
            exit();
        }
    } catch (Exception $e) {
        error_log('Delete error: ' . $e->getMessage());
        echo "<script>alert('Error deleting appointment: " . addslashes($e->getMessage()) . "'); window.location.href = 'admin-panel.php#list-app';</script>";
        exit();
    }
}

if(isset($_POST['submit'])) {
    $pid = $_POST['pid'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $doctor = $_POST['doctor'];
    $docFees = $_POST['docFees'];
    $appdate = $_POST['appdate'];
    $apptime = $_POST['apptime'];
    
    try {
        // Check if appointment slot is available
        $existingAppointment = $mongoOps->db->appointments->findOne([
            'doctor' => $doctor,
            'appdate' => new MongoDB\BSON\UTCDateTime(strtotime($appdate) * 1000),
            'apptime' => $apptime
        ]);
        
        if($existingAppointment) {
            echo "<script>alert('Appointment slot already booked!');</script>";
        } else {
            $appointmentData = [
                'pid' => (int)$pid,
                'fname' => $fname,
                'lname' => $lname,
                'gender' => $gender,
                'email' => $email,
                'contact' => $contact,
                'doctor' => $doctor,
                'docFees' => (int)$docFees,
                'appdate' => new MongoDB\BSON\UTCDateTime(strtotime($appdate) * 1000),
                'apptime' => $apptime,
                'userStatus' => 1,
                'doctorStatus' => 1
            ];
            
            $result = $mongoOps->db->appointments->insertOne($appointmentData);
            if($result->getInsertedCount() > 0) {
                echo "<script>alert('Appointment scheduled successfully!');</script>";
            }
        }
    } catch (Exception $e) {
        echo "<script>alert('Error: " . $e->getMessage() . "');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="style.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
      <a class="navbar-brand" href="#"><i class="fa fa-user-plus" aria-hidden="true"></i> Global Hospital </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
         <ul class="navbar-nav mr-auto">
           <li class="nav-item">
            <a class="nav-link" href="logout1.php"><i class="fa fa-sign-out" aria-hidden="true"></i>Logout</a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="#"></a>
          </li>
        </ul>
      </div>
    </nav>
  </head>
  <style type="text/css">
    button:hover{cursor:pointer;}
    #inputbtn:hover{cursor:pointer;}
  </style>
  <body style="padding-top:50px;">
   <div class="container-fluid" style="margin-top:20px;">
    <!-- Welcome Message at Top -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card bg-primary text-white p-4 shadow rounded">
                <div class="card-body">
                    <h2 class="card-title">Welcome, Admin!</h2>
                    <p class="card-text">Manage hospital operations, appointments, and records here.</p>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
  <div class="col-md-4" style="max-width:25%;margin-top: 3%;">
    <div class="list-group" id="list-tab" role="tablist">
      <a class="list-group-item list-group-item-action active" id="list-dash-list" data-toggle="list" href="#list-dash" role="tab" aria-controls="home">Dashboard</a>
      <a class="list-group-item list-group-item-action" href="#list-app" id="list-app-list"  role="tab"    aria-controls="home" data-toggle="list">Appointments</a>
      <a class="list-group-item list-group-item-action" href="#list-pres" id="list-pres-list"  role="tab" data-toggle="list" aria-controls="home">Prescription</a>
      <a class="list-group-item list-group-item-action" href="#list-settings" id="list-settings-list"  role="tab" data-toggle="list" aria-controls="home">Schedule Appointment</a>
    </div><br>
  </div>
  <div class="col-md-8" style="margin-top: 3%;">
    <div class="tab-content" id="nav-tabContent" style="width: 950px;">
      <div class="tab-pane fade show active" id="list-dash" role="tabpanel" aria-labelledby="list-dash-list">
        <div class="container-fluid container-fullw bg-white" >
          <!-- Summary Cards Row -->
          <div class="row mb-4">
            <?php
            try {
              $totalPatients = $mongoOps->db->patients->countDocuments();
              $totalDoctors = $mongoOps->db->doctors->countDocuments();
              $totalAppointments = $mongoOps->db->appointments->countDocuments();
              $totalPrescriptions = $mongoOps->db->prescriptions->countDocuments();
            } catch (Exception $e) {
              $totalPatients = $totalDoctors = $totalAppointments = $totalPrescriptions = 0;
            }
            ?>
            <div class="col-md-3 mb-3">
              <div class="card text-white bg-info h-100">
                <div class="card-body text-center">
                  <h5 class="card-title">Patients</h5>
                  <h2><?php echo $totalPatients; ?></h2>
                </div>
              </div>
            </div>
            <div class="col-md-3 mb-3">
              <div class="card text-white bg-success h-100">
                <div class="card-body text-center">
                  <h5 class="card-title">Doctors</h5>
                  <h2><?php echo $totalDoctors; ?></h2>
                </div>
              </div>
            </div>
            <div class="col-md-3 mb-3">
              <div class="card text-white bg-warning h-100">
                <div class="card-body text-center">
                  <h5 class="card-title">Appointments</h5>
                  <h2><?php echo $totalAppointments; ?></h2>
                </div>
              </div>
            </div>
            <div class="col-md-3 mb-3">
              <div class="card text-white bg-danger h-100">
                <div class="card-body text-center">
                  <h5 class="card-title">Prescriptions</h5>
                  <h2><?php echo $totalPrescriptions; ?></h2>
                </div>
              </div>
            </div>
          </div>
          <!-- End Summary Cards Row -->
          <!-- Quick links row removed as per user request -->
        </div>
      </div>

      <div class="tab-pane fade" id="list-app" role="tabpanel" aria-labelledby="list-app-list">
        <div class="col-md-8">
          <form class="form-group" action="appsearch.php" method="post">
            <div class="row">
              <div class="col-md-10"><input type="text" name="app_contact" placeholder="Enter Contact" class="form-control"></div>
              <div class="col-md-2"><input type="submit" name="app_search_submit" class="btn btn-primary" value="Search"></div>
            </div>
          </form>
        </div>
        <table class="table table-hover">
          <thead>
            <tr>
              <th scope="col">Appointment ID</th>
              <th scope="col">Patient Name</th>
              <th scope="col">Doctor Name</th>
              <th scope="col">Date</th>
              <th scope="col">Time</th>
              <th scope="col">Status</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            try {
                $appointments = $mongoOps->db->appointments->find([
                    '$or' => [
                        ['userStatus' => 1],
                        ['userStatus' => ['$exists' => false]]
                    ]
                ])->toArray();
                if (empty($appointments)) {
                  echo '<tr><td colspan="7" class="text-center">No appointments found.</td></tr>';
                } else {
                  foreach($appointments as $appointment) {
                      $appdate = isset($appointment['appdate']) && $appointment['appdate'] instanceof MongoDB\BSON\UTCDateTime ? $appointment['appdate']->toDateTime()->format('Y-m-d') : 'N/A';
                      $status = "Active";
                      if(isset($appointment['userStatus']) && $appointment['userStatus'] == 0 && isset($appointment['doctorStatus']) && $appointment['doctorStatus'] == 1) {
                          $status = "Cancelled by Patient";
                      } else if(isset($appointment['userStatus']) && $appointment['userStatus'] == 1 && isset($appointment['doctorStatus']) && $appointment['doctorStatus'] == 0) {
                          $status = "Cancelled by Doctor";
                      }
                      // Fetch patient name
                      $patientName = '';
                      if (!empty($appointment['fname']) || !empty($appointment['lname'])) {
                        $patientName = htmlspecialchars(($appointment['fname'] ?? '') . ' ' . ($appointment['lname'] ?? ''));
                      } else if (!empty($appointment['pid'])) {
                        // Try to fetch from patients collection, but fallback to Unknown
                        try {
                          $patient = $mongoOps->db->patients->findOne([
                            '_id' => new MongoDB\BSON\ObjectId($appointment['pid'])
                          ]);
                          $patientName = $patient ? htmlspecialchars($patient['fname'] . ' ' . $patient['lname']) : 'Unknown';
                        } catch (Exception $e) {
                          $patientName = 'Unknown';
                        }
                      } else {
                        $patientName = 'Unknown';
                      }
                      // Fetch doctor name
                      $doctorName = '';
                      if (!empty($appointment['doctor'])) {
                        $doctor = $mongoOps->db->doctors->findOne(['username' => $appointment['doctor']]);
                        $doctorName = $doctor ? htmlspecialchars($doctor['username']) : htmlspecialchars($appointment['doctor']);
                      } else {
                        $doctorName = 'Unknown';
                      }
                      echo "<tr>
                          <td>".htmlspecialchars($appointment['_id'])."</td>
                          <td>".$patientName."</td>
                          <td>".$doctorName."</td>
                          <td>".htmlspecialchars($appointment['appdate'])."</td>
                          <td>".htmlspecialchars($appointment['apptime'] ?? '')."</td>
                          <td>".htmlspecialchars($status)."</td>
                          <td>
                              <a href=\"admin-panel.php?ID=".htmlspecialchars($appointment['_id'])."\" class=\"btn btn-danger btn-sm\" onclick=\"return confirm('Are you sure you want to cancel this appointment?')\">Cancel</a>
                              <button type=\"button\" class=\"btn btn-warning btn-sm\" onclick=\"showRescheduleForm('".htmlspecialchars($appointment['_id'])."')\">Reschedule</button>
                              <form method=\"post\" id=\"reschedule-form-".htmlspecialchars($appointment['_id'])."\" style=\"display:none; margin-top:10px;\">
                                  <input type=\"hidden\" name=\"reschedule_id\" value=\"".htmlspecialchars($appointment['_id'])."\">
                                  <input type=\"date\" name=\"new_date\" required value=\"".($appdate != 'N/A' ? $appdate : '')."\">
                                  <select name=\"new_time\" required style=\"margin-left:5px;\">
                                      <option value=\"\" disabled selected>Select Time</option>
                                      <option value=\"09:00\">09:00 AM</option>
                                      <option value=\"09:30\">09:30 AM</option>
                                      <option value=\"10:00\">10:00 AM</option>
                                      <option value=\"10:30\">10:30 AM</option>
                                      <option value=\"11:00\">11:00 AM</option>
                                      <option value=\"11:30\">11:30 AM</option>
                                      <option value=\"12:00\">12:00 PM</option>
                                      <option value=\"14:00\">02:00 PM</option>
                                      <option value=\"14:30\">02:30 PM</option>
                                      <option value=\"15:00\">03:00 PM</option>
                                      <option value=\"15:30\">03:30 PM</option>
                                      <option value=\"16:00\">04:00 PM</option>
                                      <option value=\"16:30\">04:30 PM</option>
                                      <option value=\"17:00\">05:00 PM</option>
                                  </select>
                                  <button type=\"submit\" class=\"btn btn-success btn-sm\" style=\"margin-left:5px;\">Save</button>
                                  <button type=\"button\" class=\"btn btn-secondary btn-sm\" style=\"margin-left:5px;\" onclick=\"hideRescheduleForm('".htmlspecialchars($appointment['_id'])."')\">Cancel</button>
                              </form>
                              <a href=\"admin-panel.php?deleteID=".htmlspecialchars($appointment['_id'])."\" class=\"btn btn-danger btn-sm\" onclick=\"return confirm('Are you sure you want to permanently delete this appointment? This cannot be undone.')\">Delete</a>
                          </td>
                      </tr>";
                  }
                }
            } catch (Exception $e) {
                echo "<tr><td colspan='7' class='text-danger'>Error: " . htmlspecialchars($e->getMessage()) . "</td></tr>";
            }
            ?>
          </tbody>
        </table>
      </div>

      <div class="tab-pane fade" id="list-pres" role="tabpanel" aria-labelledby="list-pres-list">
        <div class="col-md-8">
          <form class="form-group" action="prescriptionsearch.php" method="post">
            <div class="row">
              <div class="col-md-10"><input type="text" name="pres_contact" placeholder="Enter Contact" class="form-control"></div>
              <div class="col-md-2"><input type="submit" name="pres_search_submit" class="btn btn-primary" value="Search"></div>
            </div>
          </form>
        </div>
        <table class="table table-hover">
          <thead>
            <tr>
              <th scope="col">Patient Name</th>
              <th scope="col">Doctor Name</th>
              <th scope="col">Date</th>
              <th scope="col">Diagnosis</th>
              <th scope="col">Medications</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            try {
                $prescriptions = $mongoOps->db->prescriptions->find()->toArray();
                if (empty($prescriptions)) {
                  echo '<tr><td colspan="5" class="text-center">No prescriptions found.</td></tr>';
                } else {
                  foreach($prescriptions as $prescription) {
                      $date = isset($prescription['date']) && $prescription['date'] instanceof MongoDB\BSON\UTCDateTime ? $prescription['date']->toDateTime()->format('Y-m-d') : (isset($prescription['appdate']) && $prescription['appdate'] instanceof MongoDB\BSON\UTCDateTime ? $prescription['appdate']->toDateTime()->format('Y-m-d') : 'N/A');
                      // Fetch patient name
                      $patientName = '';
                      if (!empty($prescription['pid'])) {
                        $patient = $mongoOps->db->patients->findOne(['_id' => new MongoDB\BSON\ObjectId($prescription['pid'])]);
                        $patientName = $patient ? htmlspecialchars($patient['fname'] . ' ' . $patient['lname']) : 'Unknown';
                      } else if (!empty($prescription['fname']) || !empty($prescription['lname'])) {
                        $patientName = htmlspecialchars(($prescription['fname'] ?? '') . ' ' . ($prescription['lname'] ?? ''));
                      } else {
                        $patientName = 'Unknown';
                      }
                      // Fetch doctor name
                      $doctorName = '';
                      if (!empty($prescription['doctor'])) {
                        $doctor = $mongoOps->db->doctors->findOne(['username' => $prescription['doctor']]);
                        $doctorName = $doctor ? htmlspecialchars($doctor['username']) : htmlspecialchars($prescription['doctor']);
                      } else {
                        $doctorName = 'Unknown';
                      }
                      echo "<tr>
                          <td>".$patientName."</td>
                          <td>".$doctorName."</td>
                          <td>".$date."</td>
                          <td>".htmlspecialchars($prescription['disease'] ?? $prescription['diagnosis'] ?? '')."</td>
                          <td>";
                      if (!empty($prescription['medications'])) {
                        foreach($prescription['medications'] as $med) {
                          echo htmlspecialchars($med['name'] . ' - ' . $med['dosage']) . '<br>';
                        }
                      } else {
                        echo htmlspecialchars($prescription['prescription'] ?? '');
                      }
                      echo "</td></tr>";
                  }
                }
            } catch (Exception $e) {
                echo "<tr><td colspan='5' class='text-danger'>Error: " . htmlspecialchars($e->getMessage()) . "</td></tr>";
            }
            ?>
          </tbody>
        </table>
      </div>

      <div class="tab-pane fade" id="list-settings" role="tabpanel" aria-labelledby="list-settings-list">
        <form class="form-group" method="post" action="admin-panel.php">
          <div class="row">
            <div class="col-md-4"><label>Patient ID:</label></div>
            <div class="col-md-8"><input type="text" class="form-control" name="pid" required></div><br><br>
            <div class="col-md-4"><label>First Name:</label></div>
            <div class="col-md-8"><input type="text" class="form-control" name="fname" required></div><br><br>
            <div class="col-md-4"><label>Last Name:</label></div>
            <div class="col-md-8"><input type="text" class="form-control" name="lname" required></div><br><br>
            <div class="col-md-4"><label for="gender">Gender:</label></div>
            <div class="col-md-8">
              <label for="gender" style="font-weight: 500; margin-bottom: 4px; display: block; color: #007bff;">Gender <span style="color: red">*</span></label>
              <select id="gender" name="gender" class="form-control" required>
                <option value="" disabled selected>Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            </div><br><br>
            <div class="col-md-4"><label>Email:</label></div>
            <div class="col-md-8"><input type="email" class="form-control" name="email" required></div><br><br>
            <div class="col-md-4"><label>Contact:</label></div>
            <div class="col-md-8"><input type="text" class="form-control" name="contact" required></div><br><br>
            <div class="col-md-4"><label>Doctor:</label></div>
            <div class="col-md-8">
              <select name="doctor" class="form-control" required>
                <option value="" disabled selected>Select Doctor</option>
                <?php
                try {
                    $doctors = $mongoOps->db->doctors->find([], [
                        'projection' => ['username' => 1, 'docFees' => 1, '_id' => 0]
                    ])->toArray();
                    
                    foreach($doctors as $doctor) {
                        echo '<option value="'.htmlspecialchars($doctor['username']).'" data-fees="'.htmlspecialchars($doctor['docFees']).'">'.htmlspecialchars($doctor['username']).'</option>';
                    }
                } catch (Exception $e) {
                    echo '<option value="">Error loading doctors</option>';
                }
                ?>
              </select>
            </div><br><br>
            <div class="col-md-4"><label>Consultancy Fees:</label></div>
            <div class="col-md-8"><input type="text" class="form-control" name="docFees" id="docFees" readonly></div><br><br>
            <div class="col-md-4"><label>Appointment Date:</label></div>
            <div class="col-md-8"><input type="date" class="form-control" name="appdate" required></div><br><br>
            <div class="col-md-4"><label>Appointment Time:</label></div>
            <div class="col-md-8">
              <select name="apptime" class="form-control" required>
                <option value="" disabled selected>Select Time</option>
                <option value="09:00">09:00 AM</option>
                <option value="09:30">09:30 AM</option>
                <option value="10:00">10:00 AM</option>
                <option value="10:30">10:30 AM</option>
                <option value="11:00">11:00 AM</option>
                <option value="11:30">11:30 AM</option>
                <option value="12:00">12:00 PM</option>
                <option value="14:00">02:00 PM</option>
                <option value="14:30">02:30 PM</option>
                <option value="15:00">03:00 PM</option>
                <option value="15:30">03:30 PM</option>
                <option value="16:00">04:00 PM</option>
                <option value="16:30">04:30 PM</option>
                <option value="17:00">05:00 PM</option>
              </select>
            </div><br><br>
          </div>
          <input type="submit" name="submit" value="Schedule Appointment" class="btn btn-primary">
        </form>
      </div>
    </div>
  </div>
</div>
   </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
    <script src="admin.js"></script>
  </body>
</html>
