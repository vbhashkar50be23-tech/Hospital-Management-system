<?php
require_once __DIR__ . '/vendor/autoload.php';

// MongoDB Atlas credentials
$username = "YOUR_MONGODB_USERNAME";  // Replace with your actual username
$password = "YOUR_MONGODB_PASSWORD";  // Replace with your actual password
$cluster = "cluster0.7hindzb.mongodb.net";

try {
    echo "<h3>Testing MongoDB Atlas Connection:</h3>";
    
    // Create the MongoDB client
    $client = new MongoDB\Client(
        "mongodb+srv://ipsitchaudhuri:BdbS9Vb6qE9Ntml4@cluster0.t3ldumx.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0",
        [
            'serverSelectionTimeoutMS' => 30000,
            'connectTimeoutMS' => 30000,
        ]
    );
    
    // Test connection and list all databases
    echo "<h4>Available Databases:</h4>";
    $databases = $client->listDatabases();
    foreach ($databases as $database) {
        echo "<p>Database: " . $database->getName() . "</p>";
    }
    
    // Select database
    $db = $client->myhmsdb;
    echo "<h4>Selected Database: myhmsdb</h4>";
    
    // List all collections in the database
    echo "<h4>Collections in myhmsdb:</h4>";
    $collections = $db->listCollections();
    $collectionCount = 0;
    foreach ($collections as $collection) {
        $collectionCount++;
        echo "<p>Collection: " . $collection->getName() . "</p>";
    }
    
    if ($collectionCount === 0) {
        echo "<p style='color: orange;'>No collections found. Creating required collections...</p>";
        
        // Create required collections
        $requiredCollections = ['patients', 'doctors', 'appointments', 'prescriptions', 'receptionists'];
        foreach ($requiredCollections as $collection) {
            try {
                $db->createCollection($collection);
                echo "<p style='color: green;'>Created collection: " . $collection . "</p>";
            } catch (Exception $e) {
                echo "<p style='color: red;'>Error creating collection " . $collection . ": " . $e->getMessage() . "</p>";
            }
        }
    }
    
    // Test basic operations
    echo "<h4>Testing Basic Operations:</h4>";
    $collection = $db->test;
    $result = $collection->insertOne(['test' => 'connection']);
    echo "<p style='color: green;'>Successfully performed test write operation!</p>";
    
    $collection->deleteOne(['test' => 'connection']);
    echo "<p style='color: green;'>Successfully performed test delete operation!</p>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
    echo "<pre>";
    echo "Error Code: " . $e->getCode() . "\n";
    echo "Error Message: " . $e->getMessage() . "\n";
    echo "Stack Trace:\n" . $e->getTraceAsString() . "\n";
    echo "</pre>";
}
?> 