<?php

class MongoDBOperations {
    public $db;
    public $client;
    
    public function __construct($db, $client) {
        $this->db = $db;
        $this->client = $client;
    }
    
    // Patient Operations
    public function createPatient($data) {
        try {
            $result = $this->db->patients->insertOne([
                'fname' => $data['fname'],
                'lname' => $data['lname'],
                'gender' => $data['gender'],
                'email' => $data['email'],
                'contact' => $data['contact'],
                'password' => password_hash($data['password'], PASSWORD_DEFAULT),
                'created_at' => new MongoDB\BSON\UTCDateTime()
            ]);
            return $result->getInsertedId();
        } catch (Exception $e) {
            throw new Exception("Failed to create patient: " . $e->getMessage());
        }
    }
    
    public function findPatient($email) {
        try {
            return $this->db->patients->findOne(['email' => $email]);
        } catch (Exception $e) {
            throw new Exception("Failed to find patient: " . $e->getMessage());
        }
    }
    
    // Doctor Operations
    public function createDoctor($data) {
        try {
            $result = $this->db->doctors->insertOne([
                'username' => $data['username'],
                'password' => password_hash($data['password'], PASSWORD_DEFAULT),
                'spec' => $data['spec'] ?? '',
                'docFees' => $data['docFees'] ?? 0,
                'email' => $data['email'],
                'created_at' => new MongoDB\BSON\UTCDateTime()
            ]);
            return $result->getInsertedId();
        } catch (Exception $e) {
            throw new Exception("Failed to create doctor: " . $e->getMessage());
        }
    }
    
    public function getDoctor($email) {
        return $this->db->doctors->findOne(['email' => $email]);
    }
    
    // Appointment Operations
    public function createAppointment($data) {
        try {
            $result = $this->db->appointments->insertOne([
                'fname' => $data['fname'],
                'lname' => $data['lname'],
                'email' => $data['email'],
                'contact' => $data['contact'],
                'doctor' => $data['doctor'],
                'docFees' => $data['docFees'],
                'appdate' => new MongoDB\BSON\UTCDateTime(strtotime($data['appdate']) * 1000),
                'apptime' => $data['apptime'],
                'userStatus' => 1,
                'doctorStatus' => 1,
                'created_at' => new MongoDB\BSON\UTCDateTime()
            ]);
            return $result->getInsertedId();
        } catch (Exception $e) {
            throw new Exception("Failed to create appointment: " . $e->getMessage());
        }
    }
    
    public function updateAppointmentStatus($contact, $status) {
        try {
            return $this->db->appointments->updateOne(
                ['contact' => $contact],
                ['$set' => ['userStatus' => (int)$status]]
            );
        } catch (Exception $e) {
            throw new Exception("Failed to update appointment status: " . $e->getMessage());
        }
    }
    
    // Prescription Operations
    public function createPrescription($data) {
        try {
            $result = $this->db->prescriptions->insertOne([
                'pid' => new MongoDB\BSON\ObjectId($data['pid']),
                'disease' => $data['disease'],
                'allergies' => $data['allergies'],
                'prescription' => $data['prescription'],
                'created_at' => new MongoDB\BSON\UTCDateTime()
            ]);
            return $result->getInsertedId();
        } catch (Exception $e) {
            throw new Exception("Failed to create prescription: " . $e->getMessage());
        }
    }
    
    // Search Operations with Projection
    public function searchPatients($query) {
        return $this->db->patients->find(
            ['$or' => [
                ['fname' => ['$regex' => $query, '$options' => 'i']],
                ['lname' => ['$regex' => $query, '$options' => 'i']],
                ['email' => ['$regex' => $query, '$options' => 'i']]
            ]],
            ['projection' => ['password' => 0]] // Exclude password from results
        )->toArray();
    }
    
    public function searchDoctors($query) {
        return $this->db->doctors->find(
            ['$or' => [
                ['username' => ['$regex' => $query, '$options' => 'i']],
                ['spec' => ['$regex' => $query, '$options' => 'i']]
            ]],
            ['projection' => ['password' => 0]] // Exclude password from results
        )->toArray();
    }
    
    // Aggregation Example
    public function getDoctorAppointmentStats($doctorName) {
        return $this->db->appointments->aggregate([
            ['$match' => ['doctor' => $doctorName]],
            ['$group' => [
                '_id' => ['$dateToString' => ['format' => '%Y-%m-%d', 'date' => '$appdate']],
                'count' => ['$sum' => 1],
                'totalFees' => ['$sum' => '$docFees']
            ]],
            ['$sort' => ['_id' => 1]]
        ])->toArray();
    }
    
    // Delete Operations
    public function deleteAppointment($appointmentId) {
        return $this->db->appointments->deleteOne(['_id' => new MongoDB\BSON\ObjectId($appointmentId)]);
    }
    
    public function deletePrescription($prescriptionId) {
        return $this->db->prescriptions->deleteOne(['_id' => new MongoDB\BSON\ObjectId($prescriptionId)]);
    }
}
?> 