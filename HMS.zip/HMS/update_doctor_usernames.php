<?php
require_once 'config.php';
require_once 'mongodb_operations.php';

try {
    // Update Arun's username in doctors collection
    $result = $mongoOps->db->doctors->updateOne(
        ['username' => 'dr.arun'],
        ['$set' => ['username' => 'arun']]
    );
    echo "Updated Arun's username in doctors collection<br>";

    // Update Kunal's username in doctors collection
    $result = $mongoOps->db->doctors->updateOne(
        ['username' => 'dr.kunal'],
        ['$set' => ['username' => 'kunal']]
    );
    echo "Updated Kunal's username in doctors collection<br>";

    // Update Rohit's username in doctors collection
    $result = $mongoOps->db->doctors->updateOne(
        ['username' => 'dr.rohit'],
        ['$set' => ['username' => 'rohit']]
    );
    echo "Updated Rohit's username in doctors collection<br>";

    // Update appointments collection
    $result = $mongoOps->db->appointments->updateMany(
        ['doctor' => 'dr.arun'],
        ['$set' => ['doctor' => 'arun']]
    );
    echo "Updated appointments for Arun<br>";

    $result = $mongoOps->db->appointments->updateMany(
        ['doctor' => 'dr.kunal'],
        ['$set' => ['doctor' => 'kunal']]
    );
    echo "Updated appointments for Kunal<br>";

    $result = $mongoOps->db->appointments->updateMany(
        ['doctor' => 'dr.rohit'],
        ['$set' => ['doctor' => 'rohit']]
    );
    echo "Updated appointments for Rohit<br>";

    // Update prescriptions collection
    $result = $mongoOps->db->prescriptions->updateMany(
        ['doctor' => 'dr.arun'],
        ['$set' => ['doctor' => 'arun']]
    );
    echo "Updated prescriptions for Arun<br>";

    $result = $mongoOps->db->prescriptions->updateMany(
        ['doctor' => 'dr.kunal'],
        ['$set' => ['doctor' => 'kunal']]
    );
    echo "Updated prescriptions for Kunal<br>";

    $result = $mongoOps->db->prescriptions->updateMany(
        ['doctor' => 'dr.rohit'],
        ['$set' => ['doctor' => 'rohit']]
    );
    echo "Updated prescriptions for Rohit<br>";

    echo "<br>All usernames have been updated successfully!<br>";
    echo "You can now log in with the new usernames:<br>";
    echo "- Arun (password: doctor123)<br>";
    echo "- Kunal (password: doctor123)<br>";
    echo "- Rohit (password: doctor123)<br>";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?> 