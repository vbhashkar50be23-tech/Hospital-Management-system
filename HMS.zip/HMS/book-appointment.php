<?php
session_start();
require_once 'config.php';
require_once 'mongodb_operations.php';

if(!isset($_SESSION['username']) || !isset($_SESSION['pid'])) {
    header("Location: index1.php");
    exit();
}

if(isset($_POST['book_appointment'])) {
    $doctor = $_POST['doctor'];
    $appdate = $_POST['appdate'];
    $apptime = $_POST['apptime'];
    $pid = $_SESSION['pid'];
    
    try {
        // Get doctor's consultation fee
        $doctorInfo = $mongoOps->db->doctors->findOne(['username' => $doctor]);
        if(!$doctorInfo) {
            throw new Exception("Doctor not found");
        }
        
        $appointmentData = [
            'pid' => $pid,
            'doctor' => $doctor,
            'appdate' => $appdate,
            'apptime' => $apptime,
            'status' => 'Pending',
            'docFees' => $doctorInfo['docFees'],
            'created_at' => new MongoDB\BSON\UTCDateTime(),
            'userStatus' => 1,
            'doctorStatus' => 1
        ];
        
        $result = $mongoOps->db->appointments->insertOne($appointmentData);
        
        if($result->getInsertedCount() > 0) {
            echo("<script>alert('Appointment booked successfully!');
                  window.location.href = 'patient-panel.php';</script>");
        } else {
            throw new Exception("Failed to book appointment");
        }
    } catch (Exception $e) {
        echo("<script>alert('Error: " . $e->getMessage() . "');
              window.location.href = 'patient-panel.php';</script>");
    }
}
?> 