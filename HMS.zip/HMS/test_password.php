<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    
    try {
        $user = $mongoOps->findPatient($email);
        
        if ($user) {
            echo "<h3>User found:</h3>";
            echo "Name: " . htmlspecialchars($user['fname'] . ' ' . $user['lname']) . "<br>";
            echo "Email: " . htmlspecialchars($user['email']) . "<br>";
            echo "Stored password hash: " . htmlspecialchars($user['password']) . "<br>";
            
            if (password_verify($password, $user['password'])) {
                echo "<p style='color: green;'>Password is correct!</p>";
            } else {
                echo "<p style='color: red;'>Password is incorrect!</p>";
            }
        } else {
            echo "<p style='color: red;'>User not found!</p>";
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>

<form method="post">
    <h3>Test Password Verification</h3>
    <div>
        <label>Email:</label><br>
        <input type="email" name="email" required>
    </div>
    <div>
        <label>Password:</label><br>
        <input type="password" name="password" required>
    </div>
    <div>
        <input type="submit" value="Test Password">
    </div>
</form> 