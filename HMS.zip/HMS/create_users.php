<?php
require_once 'config.php';
require_once 'mongodb_operations.php';

try {
    // Create admin in receptionists collection (this will always run)
    $adminReceptionist = [
        'username' => 'admin',
        'password' => password_hash('admin123', PASSWORD_DEFAULT),
        'email' => 'admin@hospital.com',
        'role' => 'Administrator',
        'created_at' => new MongoDB\BSON\UTCDateTime()
    ];
    $mongoOps->db->receptionists->updateOne(
        ['username' => 'admin'],
        ['$set' => $adminReceptionist],
        ['upsert' => true]
    );
    echo "<p style='color: green;'>Admin created/updated in receptionists collection!</p>";
    echo "<p>Username: admin</p>";
    echo "<p>Password: admin123</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}
?> 