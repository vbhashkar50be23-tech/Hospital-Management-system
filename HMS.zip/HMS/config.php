<?php
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/mongodb_operations.php';

try {
    // Create the MongoDB client with more resilient options
    $client = new MongoDB\Client(
        "mongodb+srv://ipsitchaudhuri:BdbS9Vb6qE9Ntml4@cluster0.t3ldumx.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0",
        [
            'serverSelectionTimeoutMS' => 30000,  // Increased timeout
            'connectTimeoutMS' => 30000,         // Increased connection timeout
            'socketTimeoutMS' => 30000,          // Socket timeout
            'maxPoolSize' => 50,                 // Connection pool size
            'minPoolSize' => 10,                 // Minimum connections to maintain
            'retryWrites' => true,               // Enable retry for write operations
            'retryReads' => true,                // Enable retry for read operations
            'w' => 'majority',                   // Write concern
            'wTimeoutMS' => 2500,                // Write timeout
            'readPreference' => 'primaryPreferred' // Read preference
        ]
    );
    
    // Test the connection explicitly
    $client->listDatabases();
    
    // Select database
    $db = $client->myhmsdb;
    
    // Ensure required collections exist
    $requiredCollections = ['patients', 'doctors', 'appointments', 'prescriptions', 'receptionists'];
    foreach ($requiredCollections as $collection) {
        try {
            $db->createCollection($collection);
            error_log("Created collection: " . $collection);
        } catch (Exception $e) {
            // Collection might already exist, which is fine
            error_log("Note: " . $e->getMessage());
        }
    }
    
    // Create indexes for better performance
    try {
        $db->patients->createIndex(['email' => 1], ['unique' => true]);
        $db->doctors->createIndex(['username' => 1], ['unique' => true]);
        $db->doctors->createIndex(['email' => 1], ['unique' => true]);
        $db->appointments->createIndex(['pid' => 1, 'appdate' => 1]);
        $db->prescriptions->createIndex(['pid' => 1, 'appdate' => 1]);
        $db->receptionists->createIndex(['username' => 1], ['unique' => true]);
    } catch (Exception $e) {
        error_log("Warning: Could not create indexes: " . $e->getMessage());
    }
    
    // Create a global database operations instance
    global $mongoOps;
    $mongoOps = new MongoDBOperations($db, $client);
    
} catch (MongoDB\Driver\Exception\ConnectionTimeoutException $e) {
    die("Could not connect to MongoDB: " . $e->getMessage());
} catch (MongoDB\Driver\Exception\AuthenticationException $e) {
    die("MongoDB Authentication failed: " . $e->getMessage());
} catch (Exception $e) {
    die("An error occurred: " . $e->getMessage());
}
