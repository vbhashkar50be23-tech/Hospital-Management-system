<?php
session_start();
require_once 'config.php';
require_once 'mongodb_operations.php';

if(!isset($_SESSION['username']) || !isset($_SESSION['did'])) {
    header("Location: index.php");
    exit();
}

if(isset($_POST['appointment_id'])) {
    $appointmentId = $_POST['appointment_id'];
    $status = isset($_POST['confirm']) ? 'Confirmed' : 'Cancelled';
    
    try {
        $result = $mongoOps->db->appointments->updateOne(
            ['_id' => new MongoDB\BSON\ObjectId($appointmentId)],
            ['$set' => ['status' => $status]]
        );
        
        if($result->getModifiedCount() > 0) {
            echo("<script>alert('Appointment " . strtolower($status) . " successfully!');
                  window.location.href = 'doctor-panel.php';</script>");
        } else {
            throw new Exception("Failed to update appointment status");
        }
    } catch (Exception $e) {
        echo("<script>alert('Error: " . $e->getMessage() . "');
              window.location.href = 'doctor-panel.php';</script>");
    }
} else {
    header("Location: doctor-panel.php");
    exit();
}
?> 