<?php
require_once 'config.php';

try {
    echo "<h3>Checking Receptionist Collection:</h3>";
    
    // List all receptionists
    $receptionists = $mongoOps->db->receptionists->find()->toArray();
    
    if (count($receptionists) > 0) {
        echo "<p style='color: green;'>Found " . count($receptionists) . " receptionist(s) in database:</p>";
        foreach ($receptionists as $receptionist) {
            echo "<pre>";
            echo "Username: " . $receptionist['username'] . "\n";
            echo "Password Hash: " . $receptionist['password'] . "\n";
            echo "Created At: " . date('Y-m-d H:i:s', $receptionist['created_at']->toDateTime()->getTimestamp()) . "\n";
            echo "</pre>";
            
            // Test password verification
            if (password_verify('admin123', $receptionist['password'])) {
                echo "<p style='color: green;'>Password verification successful!</p>";
            } else {
                echo "<p style='color: red;'>Password verification failed!</p>";
            }
        }
    } else {
        echo "<p style='color: red;'>No receptionists found in database!</p>";
    }
    
    // Check collection name
    echo "<h3>Available Collections:</h3>";
    $collections = $mongoOps->db->listCollections();
    foreach ($collections as $collection) {
        echo "<p>" . $collection->getName() . "</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}
?> 