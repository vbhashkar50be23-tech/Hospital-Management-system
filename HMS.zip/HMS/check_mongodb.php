<?php
require_once 'config.php';

try {
    echo "<h3>MongoDB Connection Test:</h3>";
    
    // Test database connection
    $collections = $mongoOps->db->listCollections();
    echo "<p style='color: green;'>Successfully connected to MongoDB!</p>";
    
    // List all databases
    echo "<h3>Available Databases:</h3>";
    $databases = $mongoOps->client->listDatabases();
    foreach ($databases as $database) {
        echo "<p>" . $database->getName() . "</p>";
    }
    
    // List all collections in current database
    echo "<h3>Collections in current database:</h3>";
    $collections = $mongoOps->db->listCollections();
    $hasCollections = false;
    foreach ($collections as $collection) {
        $hasCollections = true;
        echo "<p>" . $collection->getName() . "</p>";
    }
    if (!$hasCollections) {
        echo "<p style='color: orange;'>No collections found in current database.</p>";
    }
    
    // Try to create receptionists collection
    echo "<h3>Creating Receptionists Collection:</h3>";
    try {
        $mongoOps->db->createCollection('receptionists');
        echo "<p style='color: green;'>Successfully created receptionists collection!</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>Note: " . $e->getMessage() . "</p>";
    }
    
    // Check if we can write to the database
    echo "<h3>Testing Database Write Access:</h3>";
    try {
        $testResult = $mongoOps->db->receptionists->insertOne([
            'test' => true,
            'timestamp' => new MongoDB\BSON\UTCDateTime()
        ]);
        echo "<p style='color: green;'>Successfully wrote to database!</p>";
        
        // Clean up test document
        $mongoOps->db->receptionists->deleteOne(['test' => true]);
    } catch (Exception $e) {
        echo "<p style='color: red;'>Error writing to database: " . $e->getMessage() . "</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>MongoDB Connection Error: " . $e->getMessage() . "</p>";
    echo "<pre>";
    echo "Error Code: " . $e->getCode() . "\n";
    echo "Error Message: " . $e->getMessage() . "\n";
    echo "Stack Trace:\n" . $e->getTraceAsString() . "\n";
    echo "</pre>";
}
?> 