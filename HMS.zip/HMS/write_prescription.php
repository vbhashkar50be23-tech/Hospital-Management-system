<?php
session_start();
require_once 'config.php';
require_once 'mongodb_operations.php';

// Check if doctor is logged in
if(!isset($_SESSION['username']) || !isset($_SESSION['did'])) {
    header("Location: index.php");
    exit();
}

$doctorName = $_SESSION['username'];
$did = $_SESSION['did'];

// Handle prescription submission
if(isset($_POST['submit_prescription'])) {
    try {
        // Get patient details
        $patient = $mongoOps->db->patients->findOne(['_id' => new MongoDB\BSON\ObjectId($_POST['patient_id'])]);
        if(!$patient) {
            throw new Exception("Patient not found");
        }

        $prescriptionData = [
            'doctor' => $doctorName,
            'pid' => $_POST['patient_id'],
            'patient_name' => $patient['fname'] . ' ' . $patient['lname'],
            'date' => new MongoDB\BSON\UTCDateTime(),
            'diagnosis' => $_POST['diagnosis'],
            'medications' => [
                [
                    'name' => $_POST['medication1'],
                    'dosage' => $_POST['dosage1'],
                    'frequency' => $_POST['frequency1'],
                    'duration' => $_POST['duration1']
                ]
            ],
            'instructions' => $_POST['instructions'],
            'follow_up_date' => $_POST['follow_up_date']
        ];

        // Add additional medications if provided
        if(!empty($_POST['medication2'])) {
            $prescriptionData['medications'][] = [
                'name' => $_POST['medication2'],
                'dosage' => $_POST['dosage2'],
                'frequency' => $_POST['frequency2'],
                'duration' => $_POST['duration2']
            ];
        }

        $result = $mongoOps->db->prescriptions->insertOne($prescriptionData);
        
        if($result->getInsertedCount() > 0) {
            echo "<script>alert('Prescription added successfully!');</script>";
            // Redirect back to doctor panel after successful submission
            echo "<script>window.location.href = 'doctor-panel.php';</script>";
            exit();
        }
    } catch (Exception $e) {
        echo "<script>alert('Error: " . $e->getMessage() . "');</script>";
    }
}

// Get doctor's recent patients
try {
    $patients = $mongoOps->db->appointments->distinct('pid', ['doctor' => $doctorName]);
    $patientDetails = [];
    foreach($patients as $pid) {
        $patient = $mongoOps->db->patients->findOne(['_id' => new MongoDB\BSON\ObjectId($pid)]);
        if($patient) {
            $patientDetails[] = [
                'id' => (string)$patient['_id'],
                'name' => $patient['fname'] . ' ' . $patient['lname']
            ];
        }
    }
} catch (Exception $e) {
    $patientDetails = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css">
    <title>Write Prescription</title>
</head>
<body>
    <div class="container mt-5">
        <h2>Write Prescription</h2>
        <form method="post" action="">
            <div class="form-group">
                <label>Select Patient:</label>
                <select name="patient_id" class="form-control" required>
                    <option value="">Select Patient</option>
                    <?php foreach($patientDetails as $patient): ?>
                        <option value="<?php echo $patient['id']; ?>"><?php echo $patient['name']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>Diagnosis:</label>
                <textarea name="diagnosis" class="form-control" rows="3" required></textarea>
            </div>

            <h4>Medication 1</h4>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Medication Name:</label>
                        <input type="text" name="medication1" class="form-control" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Dosage:</label>
                        <input type="text" name="dosage1" class="form-control" required>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Frequency:</label>
                        <input type="text" name="frequency1" class="form-control" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Duration:</label>
                        <input type="text" name="duration1" class="form-control" required>
                    </div>
                </div>
            </div>

            <h4>Medication 2 (Optional)</h4>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Medication Name:</label>
                        <input type="text" name="medication2" class="form-control">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Dosage:</label>
                        <input type="text" name="dosage2" class="form-control">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Frequency:</label>
                        <input type="text" name="frequency2" class="form-control">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Duration:</label>
                        <input type="text" name="duration2" class="form-control">
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label>Special Instructions:</label>
                <textarea name="instructions" class="form-control" rows="3"></textarea>
            </div>

            <div class="form-group">
                <label>Follow-up Date:</label>
                <input type="date" name="follow_up_date" class="form-control">
            </div>

            <button type="submit" name="submit_prescription" class="btn btn-primary">Save Prescription</button>
            <a href="doctor-panel.php" class="btn btn-secondary">Back to Dashboard</a>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js"></script>
</body>
</html> 