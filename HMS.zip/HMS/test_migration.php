<?php
require_once 'config.php';
require_once 'mongodb_operations.php';

class MigrationTest {
    private $mongoOps;
    private $testResults = [];
    
    public function __construct($mongoOps) {
        $this->mongoOps = $mongoOps;
    }
    
    private function addResult($testName, $passed, $message = '') {
        $this->testResults[] = [
            'name' => $testName,
            'passed' => $passed,
            'message' => $message
        ];
    }
    
    public function runAllTests() {
        $this->testPatientOperations();
        $this->testDoctorOperations();
        $this->testAppointmentOperations();
        $this->testPrescriptionOperations();
        $this->testContactOperations();
        
        $this->displayResults();
    }
    
    private function testPatientOperations() {
        // Test patient creation
        try {
            $patientData = [
                'fname' => 'Test',
                'lname' => 'Patient',
                'gender' => 'Male',
                'email' => 'test@example.com',
                'contact' => '1234567890',
                'password' => 'testpass'
            ];
            
            $result = $this->mongoOps->createPatient($patientData);
            $this->addResult('Patient Creation', true);
            
            // Test patient retrieval
            $patient = $this->mongoOps->db->patients->findOne(['email' => 'test@example.com']);
            $this->addResult('Patient Retrieval', $patient !== null);
            
            // Cleanup
            $this->mongoOps->db->patients->deleteOne(['email' => 'test@example.com']);
            
        } catch (Exception $e) {
            $this->addResult('Patient Operations', false, $e->getMessage());
        }
    }
    
    private function testDoctorOperations() {
        try {
            $doctorData = [
                'username' => 'TestDoctor',
                'password' => 'testpass',
                'email' => 'doctor@example.com',
                'spec' => 'General',
                'docFees' => 100
            ];
            
            $result = $this->mongoOps->createDoctor($doctorData);
            $this->addResult('Doctor Creation', true);
            
            // Test doctor retrieval
            $doctor = $this->mongoOps->db->doctors->findOne(['email' => 'doctor@example.com']);
            $this->addResult('Doctor Retrieval', $doctor !== null);
            
            // Cleanup
            $this->mongoOps->db->doctors->deleteOne(['email' => 'doctor@example.com']);
            
        } catch (Exception $e) {
            $this->addResult('Doctor Operations', false, $e->getMessage());
        }
    }
    
    private function testAppointmentOperations() {
        try {
            // Create test patient and doctor first
            $patientData = [
                'fname' => 'App',
                'lname' => 'Test',
                'gender' => 'Male',
                'email' => 'apptest@example.com',
                'contact' => '9876543210',
                'password' => 'testpass'
            ];
            $this->mongoOps->createPatient($patientData);
            
            $doctorData = [
                'username' => 'AppDoctor',
                'password' => 'testpass',
                'email' => 'appdoctor@example.com',
                'spec' => 'General',
                'docFees' => 100
            ];
            $this->mongoOps->createDoctor($doctorData);
            
            // Test appointment creation
            $appointmentData = [
                'pid' => (string)$this->mongoOps->db->patients->findOne(['email' => 'apptest@example.com'])['_id'],
                'fname' => 'App',
                'lname' => 'Test',
                'gender' => 'Male',
                'email' => 'apptest@example.com',
                'contact' => '9876543210',
                'doctor' => 'AppDoctor',
                'docFees' => 100,
                'appdate' => new MongoDB\BSON\UTCDateTime(),
                'apptime' => '10:00',
                'userStatus' => 1,
                'doctorStatus' => 1
            ];
            
            $result = $this->mongoOps->createAppointment($appointmentData);
            $this->addResult('Appointment Creation', true);
            
            // Test appointment retrieval
            $appointment = $this->mongoOps->db->appointments->findOne(['contact' => '9876543210']);
            $this->addResult('Appointment Retrieval', $appointment !== null);
            
            // Test appointment status update
            $updateResult = $this->mongoOps->updateAppointmentStatus('9876543210', 'paid');
            $this->addResult('Appointment Status Update', $updateResult->getModifiedCount() > 0);
            
            // Cleanup
            $this->mongoOps->db->appointments->deleteOne(['contact' => '9876543210']);
            $this->mongoOps->db->patients->deleteOne(['email' => 'apptest@example.com']);
            $this->mongoOps->db->doctors->deleteOne(['email' => 'appdoctor@example.com']);
            
        } catch (Exception $e) {
            $this->addResult('Appointment Operations', false, $e->getMessage());
        }
    }
    
    private function testPrescriptionOperations() {
        try {
            // Create test prescription
            $prescriptionData = [
                'doctor' => 'TestDoctor',
                'pid' => '123',
                'fname' => 'Pres',
                'lname' => 'Test',
                'appdate' => new MongoDB\BSON\UTCDateTime(),
                'apptime' => '11:00',
                'disease' => 'Test Disease',
                'allergy' => 'None',
                'prescription' => 'Test Prescription'
            ];
            
            $result = $this->mongoOps->createPrescription($prescriptionData);
            $this->addResult('Prescription Creation', true);
            
            // Test prescription retrieval
            $prescription = $this->mongoOps->db->prescriptions->findOne(['pid' => '123']);
            $this->addResult('Prescription Retrieval', $prescription !== null);
            
            // Cleanup
            $this->mongoOps->db->prescriptions->deleteOne(['pid' => '123']);
            
        } catch (Exception $e) {
            $this->addResult('Prescription Operations', false, $e->getMessage());
        }
    }
    
    private function testContactOperations() {
        try {
            // Test contact message creation
            $contactData = [
                'name' => 'Test User',
                'email' => 'contact@example.com',
                'contact' => '5555555555',
                'message' => 'Test message',
                'created_at' => new MongoDB\BSON\UTCDateTime()
            ];
            
            $result = $this->mongoOps->db->contacts->insertOne($contactData);
            $this->addResult('Contact Message Creation', true);
            
            // Test contact message retrieval
            $contact = $this->mongoOps->db->contacts->findOne(['contact' => '5555555555']);
            $this->addResult('Contact Message Retrieval', $contact !== null);
            
            // Cleanup
            $this->mongoOps->db->contacts->deleteOne(['contact' => '5555555555']);
            
        } catch (Exception $e) {
            $this->addResult('Contact Operations', false, $e->getMessage());
        }
    }
    
    private function displayResults() {
        echo "<h2>Migration Test Results</h2>";
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>Test</th><th>Status</th><th>Message</th></tr>";
        
        foreach ($this->testResults as $result) {
            $status = $result['passed'] ? 'PASSED' : 'FAILED';
            $color = $result['passed'] ? 'green' : 'red';
            echo "<tr>";
            echo "<td>{$result['name']}</td>";
            echo "<td style='color: {$color};'>{$status}</td>";
            echo "<td>{$result['message']}</td>";
            echo "</tr>";
        }
        
        echo "</table>";
        
        // Calculate summary
        $total = count($this->testResults);
        $passed = count(array_filter($this->testResults, function($r) { return $r['passed']; }));
        $failed = $total - $passed;
        
        echo "<h3>Summary</h3>";
        echo "Total Tests: {$total}<br>";
        echo "Passed: {$passed}<br>";
        echo "Failed: {$failed}<br>";
    }
}

// Run the tests
$tester = new MigrationTest($mongoOps);
$tester->runAllTests();
?> 