// Handle doctor selection and fees
document.addEventListener('DOMContentLoaded', function() {
    var doctorSelect = document.querySelector('select[name="doctor"]');
    if (doctorSelect) {
        doctorSelect.addEventListener('change', function() {
            var selectedOption = this.options[this.selectedIndex];
            var fees = selectedOption.getAttribute('data-fees');
            document.getElementById('docFees').value = fees;
        });
    }
});

// Show reschedule form
function showRescheduleForm(id) {
    var form = document.getElementById('reschedule-form-' + id);
    if (form) {
        form.style.display = 'inline-block';
    }
}

// Hide reschedule form
function hideRescheduleForm(id) {
    var form = document.getElementById('reschedule-form-' + id);
    if (form) {
        form.style.display = 'none';
    }
} 