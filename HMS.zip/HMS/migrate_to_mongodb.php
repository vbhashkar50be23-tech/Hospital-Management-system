<?php
require_once 'config.php';
require_once 'mongodb_operations.php';

// MySQL connection
$mysql_conn = new mysqli('localhost', 'root', '', 'myhmsdb');

if ($mysql_conn->connect_error) {
    die("MySQL Connection failed: " . $mysql_conn->connect_error);
}

try {
    // Migrate Patients
    $result = $mysql_conn->query("SELECT * FROM patreg");
    while ($row = $result->fetch_assoc()) {
        $mongoOps->createPatient([
            'fname' => $row['fname'],
            'lname' => $row['lname'],
            'gender' => $row['gender'],
            'email' => $row['email'],
            'contact' => $row['contact'],
            'password' => $row['password'] // Note: We're keeping the existing password
        ]);
    }
    echo "Patients migrated successfully\n";

    // Migrate Doctors
    $result = $mysql_conn->query("SELECT * FROM doctb");
    while ($row = $result->fetch_assoc()) {
        $mongoOps->createDoctor([
            'username' => $row['username'],
            'password' => $row['password'],
            'email' => $row['email'],
            'spec' => $row['spec'],
            'docFees' => $row['docFees']
        ]);
    }
    echo "Doctors migrated successfully\n";

    // Migrate Appointments
    $result = $mysql_conn->query("SELECT * FROM appointmenttb");
    while ($row = $result->fetch_assoc()) {
        $mongoOps->createAppointment([
            'pid' => $row['pid'],
            'fname' => $row['fname'],
            'lname' => $row['lname'],
            'gender' => $row['gender'],
            'email' => $row['email'],
            'contact' => $row['contact'],
            'doctor' => $row['doctor'],
            'docFees' => $row['docFees'],
            'appdate' => $row['appdate'],
            'apptime' => $row['apptime'],
            'userStatus' => $row['userStatus'],
            'doctorStatus' => $row['doctorStatus']
        ]);
    }
    echo "Appointments migrated successfully\n";

    // Migrate Prescriptions
    $result = $mysql_conn->query("SELECT * FROM prestb");
    while ($row = $result->fetch_assoc()) {
        $mongoOps->createPrescription([
            'doctor' => $row['doctor'],
            'pid' => $row['pid'],
            'fname' => $row['fname'],
            'lname' => $row['lname'],
            'appdate' => $row['appdate'],
            'apptime' => $row['apptime'],
            'disease' => $row['disease'],
            'allergy' => $row['allergy'],
            'prescription' => $row['prescription']
        ]);
    }
    echo "Prescriptions migrated successfully\n";

    echo "Migration completed successfully!\n";

} catch (Exception $e) {
    echo "Migration failed: " . $e->getMessage() . "\n";
} finally {
    $mysql_conn->close();
} 