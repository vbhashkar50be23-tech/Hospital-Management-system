<?php
require_once 'config.php';

try {
    // Get all users from the patients collection
    $users = $mongoOps->db->patients->find([], [
        'projection' => [
            'fname' => 1,
            'lname' => 1,
            'email' => 1,
            'password' => 1,
            'created_at' => 1
        ]
    ])->toArray();

    echo "<h2>User Information</h2>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Name</th><th>Email</th><th>Password Hash</th><th>Created At</th></tr>";

    foreach ($users as $user) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($user['fname'] . ' ' . $user['lname']) . "</td>";
        echo "<td>" . htmlspecialchars($user['email']) . "</td>";
        echo "<td>" . htmlspecialchars($user['password']) . "</td>";
        echo "<td>" . date('Y-m-d H:i:s', $user['created_at']->toDateTime()->getTimestamp()) . "</td>";
        echo "</tr>";
    }

    echo "</table>";

} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?> 