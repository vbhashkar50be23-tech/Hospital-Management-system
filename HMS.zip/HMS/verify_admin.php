<?php
require_once 'config.php';

try {
    // Find the admin user
    $admin = $mongoOps->db->patients->findOne(['email' => 'admin@hospital.com']);
    
    if ($admin) {
        echo "<h3>Admin User Details:</h3>";
        echo "<pre>";
        echo "Name: " . $admin['fname'] . " " . $admin['lname'] . "\n";
        echo "Email: " . $admin['email'] . "\n";
        echo "Password Hash: " . $admin['password'] . "\n";
        echo "Gender: " . $admin['gender'] . "\n";
        echo "Contact: " . $admin['contact'] . "\n";
        echo "</pre>";
        
        // Test password verification
        $testPassword = 'admin123';
        if (password_verify($testPassword, $admin['password'])) {
            echo "<p style='color: green;'>Password verification successful!</p>";
        } else {
            echo "<p style='color: red;'>Password verification failed!</p>";
        }
    } else {
        echo "<p style='color: red;'>Admin user not found in database!</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}
?> 