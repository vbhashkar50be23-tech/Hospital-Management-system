<?php
session_start();
require_once 'config.php';
require_once 'mongodb_operations.php';

// Check if user is logged in
if(!isset($_SESSION['username']) || !isset($_SESSION['pid'])) {
    header("Location: index1.php");
    exit();
}

$patientName = $_SESSION['username'];
$pid = $_SESSION['pid'];

// Get patient's appointments
try {
    $appointments = $mongoOps->db->appointments->find(
        ['pid' => $pid, 'userStatus' => 1],
        ['sort' => ['appdate' => -1, 'apptime' => -1]]
    )->toArray();
} catch (Exception $e) {
    $appointments = [];
}

// Get patient's prescriptions
try {
    $prescriptions = $mongoOps->db->prescriptions->find(
        ['pid' => $pid],
        ['sort' => ['date' => -1]]
    )->toArray();
} catch (Exception $e) {
    $prescriptions = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css">
    <title>Patient Dashboard</title>
</head>
<body style="padding-top:50px;">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
        <a class="navbar-brand" href="#"><i class="fa fa-user-plus" aria-hidden="true"></i> Global Hospital</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container-fluid" style="margin-top:50px;">
        <!-- Welcome Message at Top -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <h2 class="card-title">Welcome, <?php echo htmlspecialchars($patientName); ?>!</h2>
                        <p class="card-text">Manage your appointments and view your medical information here.</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="list-group" id="list-tab" role="tablist">
                    <a class="list-group-item list-group-item-action active" id="list-home-list" data-toggle="list" href="#list-home" role="tab">My Appointments</a>
                    <a class="list-group-item list-group-item-action" id="list-profile-list" data-toggle="list" href="#list-profile" role="tab">My Prescriptions</a>
                    <a class="list-group-item list-group-item-action" id="list-messages-list" data-toggle="list" href="#list-messages" role="tab">Book Appointment</a>
                    <a class="list-group-item list-group-item-action" id="list-settings-list" data-toggle="list" href="#list-settings" role="tab">My Profile</a>
                </div>
            </div>

            <div class="col-md-8">
                <div class="tab-content" id="nav-tabContent">
                    <div class="tab-pane fade show active" id="list-home" role="tabpanel">
                        <div class="card">
                            <div class="card-body">
                                <h4>My Appointments</h4>
                                <?php if(empty($appointments)): ?>
                                    <p>No appointments found.</p>
                                <?php else: ?>
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Doctor</th>
                                                    <th>Date</th>
                                                    <th>Time</th>
                                                    <th>Status</th>
                                                    <th>Fee</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach($appointments as $appointment): ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($appointment['doctor']); ?></td>
                                                        <td><?php echo htmlspecialchars($appointment['appdate']); ?></td>
                                                        <td><?php echo htmlspecialchars($appointment['apptime']); ?></td>
                                                        <td>
                                                            <span class="badge badge-<?php 
                                                                echo $appointment['status'] === 'Pending' ? 'warning' : 
                                                                    ($appointment['status'] === 'Confirmed' ? 'success' : 'danger'); 
                                                            ?>">
                                                                <?php echo htmlspecialchars($appointment['status']); ?>
                                                            </span>
                                                        </td>
                                                        <td>₹<?php echo htmlspecialchars($appointment['docFees']); ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="list-profile" role="tabpanel">
                        <div class="card">
                            <div class="card-body">
                                <h4>My Prescriptions</h4>
                                <?php if(empty($prescriptions)): ?>
                                    <p>No prescriptions found.</p>
                                <?php else: ?>
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Doctor</th>
                                                    <th>Diagnosis</th>
                                                    <th>Medications</th>
                                                    <th>Instructions</th>
                                                    <th>Follow-up</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach($prescriptions as $prescription): ?>
                                                    <tr>
                                                        <td><?php echo isset($prescription['date']) ? htmlspecialchars($prescription['date']->toDateTime()->format('Y-m-d')) : 'N/A'; ?></td>
                                                        <td><?php echo htmlspecialchars($prescription['doctor'] ?? ''); ?></td>
                                                        <td><?php echo htmlspecialchars($prescription['diagnosis'] ?? ''); ?></td>
                                                        <td>
                                                            <?php if(!empty($prescription['medications'])): ?>
                                                                <?php foreach($prescription['medications'] as $med): ?>
                                                                    <div><?php echo htmlspecialchars($med['name'] . ' - ' . $med['dosage']); ?></div>
                                                                <?php endforeach; ?>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td><?php echo htmlspecialchars($prescription['instructions'] ?? ''); ?></td>
                                                        <td><?php echo htmlspecialchars($prescription['follow_up_date'] ?? ''); ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="list-messages" role="tabpanel">
                        <div class="card">
                            <div class="card-body">
                                <h4>Book New Appointment</h4>
                                <form class="form-group" method="post" action="book-appointment.php">
                                    <div class="row">
                                        <div class="col-md-4"><label>Doctor:</label></div>
                                        <div class="col-md-8">
                                            <select name="doctor" class="form-control" required>
                                                <option value="" disabled selected>Select Doctor</option>
                                                <?php
                                                $doctors = $mongoOps->db->doctors->find(['spec' => ['$ne' => 'Administrator']]);
                                                foreach($doctors as $doctor) {
                                                    echo '<option value="'.htmlspecialchars($doctor['username']).'">'.htmlspecialchars($doctor['username']).' - '.htmlspecialchars($doctor['spec']).'</option>';
                                                }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="col-md-4"><label>Date:</label></div>
                                        <div class="col-md-8">
                                            <input type="date" class="form-control" name="appdate" required>
                                        </div>
                                        <div class="col-md-4"><label>Time:</label></div>
                                        <div class="col-md-8">
                                            <input type="time" class="form-control" name="apptime" required>
                                        </div>
                                        <div class="col-md-12 mt-3">
                                            <button type="submit" class="btn btn-primary" name="book_appointment">Book Appointment</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="list-settings" role="tabpanel">
                        <div class="card">
                            <div class="card-body">
                                <h4>My Profile</h4>
                                <div class="row">
                                    <div class="col-md-4"><label>Name:</label></div>
                                    <div class="col-md-8"><?php echo htmlspecialchars($patientName); ?></div>
                                    <div class="col-md-4"><label>Email:</label></div>
                                    <div class="col-md-8"><?php echo htmlspecialchars($_SESSION['email']); ?></div>
                                    <div class="col-md-4"><label>Contact:</label></div>
                                    <div class="col-md-8"><?php echo htmlspecialchars($_SESSION['contact']); ?></div>
                                    <div class="col-md-4"><label>Gender:</label></div>
                                    <div class="col-md-8"><?php echo htmlspecialchars($_SESSION['gender']); ?></div>
                                </div>
                                <div class="mt-3">
                                    <a href="update_profile.php" class="btn btn-primary">Edit Profile</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js"></script>
</body>
</html> 