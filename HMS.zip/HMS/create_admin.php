<?php
require_once 'config.php';

try {
    // Check if admin already exists
    $admin = $mongoOps->db->patients->findOne(['email' => 'admin@hospital.com']);
    
    if (!$admin) {
        // Create admin user
        $adminData = [
            'fname' => 'Admin',
            'lname' => 'User',
            'email' => 'admin@hospital.com',
            'password' => password_hash('admin123', PASSWORD_DEFAULT),
            'gender' => 'Male',
            'contact' => '1234567890',
            'created_at' => new MongoDB\BSON\UTCDateTime()
        ];
        
        $result = $mongoOps->db->patients->insertOne($adminData);
        
        if ($result->getInsertedCount() > 0) {
            echo "<h3 style='color: green;'>Admin user created successfully!</h3>";
            echo "<p>Email: admin@hospital.com</p>";
            echo "<p>Password: admin123</p>";
            echo "<p>Please change this password after first login for security.</p>";
        }
    } else {
        echo "<h3 style='color: orange;'>Admin user already exists!</h3>";
        echo "<p>Email: admin@hospital.com</p>";
        echo "<p>Password: admin123</p>";
    }
    
} catch (Exception $e) {
    echo "<h3 style='color: red;'>Error: " . $e->getMessage() . "</h3>";
}
?> 